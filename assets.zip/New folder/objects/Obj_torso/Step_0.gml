var x_distance = x_speed*delta_time/1000000
x += x_distance

x_speed -= sign(x_speed)*3
if(x_speed >= -3 or x_speed <= 3){
	x_speed = 0
}

if(place_meeting(x,y,walls)){
	while(place_meeting(x,y,walls)){
		x -= sign(x_speed)
	}
}

var y_distance = y_speed*delta_time/1000000
y += y_distance
y_speed += 800*delta_time/1000000

if(place_meeting(x,y,walls)){
	while(place_meeting(x,y,walls)){
		y -= sign(y_distance)
		y_speed = 0
	}
}

if(place_meeting(x,y,Obj_player)){
	Obj_player.y -= 60
	Obj_player.torso = 1
	instance_destroy(self)
}