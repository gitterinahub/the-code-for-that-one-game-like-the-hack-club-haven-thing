var x_distance = x_speed*delta_time/1000000
x += x_distance

x_speed -= sign(x_speed)*3*(1-flying)
if(x_speed >= -3 and x_speed <= 3){
	x_speed = 0
}

show_debug_message(x,y)

if(place_meeting(x,y,walls)){
	while(place_meeting(x,y,walls)){
		x -= sign(x_speed)
	}
	flying = 0
}

var y_distance = y_speed*delta_time/1000000
y += y_distance
y_speed += 800*delta_time/1000000*(1-flying)

if(place_meeting(x,y,walls)){
	while(place_meeting(x,y,walls)){
		y -= sign(y_distance)
		y_speed = 0
	}
	flying = 0
}

if(place_meeting(x,y,Obj_player) and Obj_player.torso == 1){
	Obj_player.y -= (not (Obj_player.left_leg or Obj_player.right_leg)) * 60
	if(Obj_player.left_leg == 1){Obj_player.right_leg = 1}
	else{Obj_player.left_leg = 1}
	instance_destroy(self)
}