if(room == Level1){
	draw_text_transformed(100,50,"like A and D to move horizontally, W to jump\nQ to eject arms, E to eject legs, R to eject head)",2,2,0)
}
if(room == Level6){
	draw_text_transformed(100,20,"this is the end, i would've made a ton more of stuff\nif it wasn't for the really strict deadline\n of not even 8 hours",2,2,0)
}