if(place_meeting(x,y,Obj_player)){
	if(room == Level1){
		room_goto(Level2)
		Obj_player.x = 150
		Obj_player.y = 350
	}
	if(room == Level2){
		room_goto(Level3)
		Obj_player.x = 150
		Obj_player.y = 350
	}
	if(room == Level3){
		room_goto(Level4)
		Obj_player.x = 250
		Obj_player.y = 900
	}
	if(room == Level4){
		room_goto(Level5)
		Obj_player.x = 150
		Obj_player.y = 350
	}
	if(room == Level5){
		room_goto(Level6)
		Obj_player.x = 150
		Obj_player.y = 350
	}
}