if(place_meeting(x,y,items)){
	image_index = 1
	instance_destroy(Obj_door)
	
}