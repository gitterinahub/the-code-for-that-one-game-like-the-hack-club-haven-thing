x_speed = 0
y_speed = 0
walls = [Obj_wall,Obj_door,Obj_nextlevel]