mask_index = Spr_collisionmask
image_xscale = (50+torso*50+right_arm*15+left_arm*15)/2
image_yscale = (50+torso*60+(left_leg or right_leg)*60)/2//
total_width = image_xscale
total_height = image_yscale

x_speed = 150*(left_leg+right_leg+0.75)/1.5

x_direction = 0
if(keyboard_check(ord("A"))){
	x_direction -= 1
}
if(keyboard_check(ord("D"))){
	x_direction += 1
}

if(limb_rotation > 40){
	rotation_direction = -1
}
if(limb_rotation < -40){
	rotation_direction = 1
}

if(x_direction != 0){
	limb_rotation += rotation_direction*3
	head_rotation += x_direction*-3
}else{
	limb_rotation = 0
}

if(torso != 0){head_rotation = 0}

var x_distance = (x_speed*x_direction+x_boost)*delta_time/1000000
x += x_distance

if(place_meeting(x,y+1,walls)){x_boost -= 300*delta_time/1000000*sign(x_boost)}
if(x_boost < 2.5 and x_boost > -2.5){
	x_boost = 0
}

if(place_meeting(x,y,walls)){
	while(place_meeting(x,y,walls)){
		x -= x_direction
	}
	x_boost /= -2
}

if(keyboard_check_pressed(ord("W")) and place_meeting(x,y+1,walls) and (left_leg == 1 or right_leg == 1)){
	y_speed = -225 * (left_leg+0.25) * (left_leg+0.25)
}

var y_distance = y_speed*delta_time/1000000
y += y_distance
y_speed += 400*delta_time/1000000

if(place_meeting(x,y,walls)){
	while(place_meeting(x,y,walls)){
		y -= sign(y_distance)
		y_speed = 0
	}
}

if(keyboard_check_pressed(ord("Q")) and (left_arm or right_arm)){
	var mouse_distance_x = mouse_x-x
	var mouse_distance_y = mouse_y-y
	var arc = arctan(mouse_distance_x/mouse_distance_y)
	var arm = instance_create_layer(x,y,"Instances",Obj_arm)
	var int = 1
	if (mouse_distance_y > 0){int = -1}
	arm.x_speed = -sin(arc)*throwing_power*int
	arm.y_speed = -cos(arc)*throwing_power*int
	arm.x = x-sin(arc)*200*int
	arm.y = y-cos(arc)*200*int
	
	if(right_arm == 1){
		right_arm = 0
	}else if(left_arm == 1){
		left_arm = 0
	}
}

if(keyboard_check_pressed(ord("E")) and (left_leg or right_leg)){
	var mouse_distance_x = mouse_x-x
	var mouse_distance_y = mouse_y-y
	var arc = arctan(mouse_distance_x/mouse_distance_y)
	var leg = instance_create_layer(x,y,"Instances",Obj_leg)
	var int = 1
	if (mouse_distance_y > 0){int = -1}
	leg.x_speed = -sin(arc)*throwing_power*1.5*int
	leg.y_speed = -cos(arc)*throwing_power*1.5*int
	leg.flying = 1
	leg.x = x-sin(arc)*200*int
	leg.y = y-cos(arc)*200*int
	
	if(right_leg == 1){
		right_leg = 0
	}else if(left_leg == 1){
		left_leg = 0
	}
}

if(keyboard_check_pressed(ord("R")) and torso){
	instance_create_layer(x,y-50,"Instances",Obj_torso)
	torso = 0
	if(right_leg == 1){
		right_leg = 0
		instance_create_layer(x,y-50,"Instances",Obj_leg)
	}
	if(left_leg == 1){
		left_leg = 0
		instance_create_layer(x,y-50,"Instances",Obj_leg)
	}
	if(left_arm == 1){
		left_arm = 0
		instance_create_layer(x,y-50,"Instances",Obj_arm)
	}
	if(right_arm == 1){
		right_arm = 0
		instance_create_layer(x,y-50,"Instances",Obj_arm)
	}
	yspeed = -400
	y -= 150
	x_boost = x_direction*300
}