//BODY PARTS
torso = 1
left_arm = 1
right_arm = 1
left_leg = 1
right_leg = 1

throwing_power = 600

head_rotation = 0
limb_rotation = 0
rotation_direction = 1

total_height = 0
total_width = 0
head_width = 50
head_height = 50
torso_width = 50
torso_height = 60
arm_width = 15
leg_height = 60

center_x = 500
center_y = 350

x_speed = 200
y_speed = 0
x_boost = 0
x_direction = 0

walls = [Obj_wall,Obj_door]