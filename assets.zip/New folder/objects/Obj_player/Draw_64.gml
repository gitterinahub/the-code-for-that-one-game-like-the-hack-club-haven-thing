var camera = view_get_camera(0)
var cam_x = camera_get_view_x(camera)
var cam_y = camera_get_view_y(camera)
layer_x("Background",cam_x)
layer_y("Background",cam_y)

draw_sprite_ext(Spr_player_head,0,x-cam_x,y-cam_y-total_height+head_height/2,1,1,head_rotation,c_white,1)
if(torso == 1){draw_sprite(Spr_player_torso,0,x-cam_x,y-cam_y-total_height+head_height/2+torso_height)}
if(left_arm == 1){draw_sprite_ext(Spr_player_arm,0,x-cam_x-32,y-cam_y-total_height+head_height,1,1,-limb_rotation,c_white,1)}
if(right_arm == 1){draw_sprite_ext(Spr_player_arm,0,x-cam_x+32,y-cam_y-total_height+head_height,-1,1,limb_rotation,c_white,1)}
if(left_leg == 1){draw_sprite_ext(Spr_player_leg,0,x-cam_x-16,y-cam_y-total_height+head_height/2+torso_height*1.5,1,1,limb_rotation,c_white,1)}
if(right_leg == 1){draw_sprite_ext(Spr_player_leg,0,x-cam_x+16,y-cam_y-total_height+head_height/2+torso_height*1.5,-1,1,-limb_rotation,c_white,1)}